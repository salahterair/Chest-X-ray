import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { ArrowLeft, Wind } from "lucide-react";

export default function Pneumothorax() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <header className="border-b border-blue-100 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Pneumothorax</h1>
          </div>
        </div>
      </header>
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-5xl mx-auto">
          <section className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Detecting Pneumothorax</h2>
            <p className="text-lg text-gray-600 mb-6">
              Pneumothorax occurs when air enters the pleural space, causing lung collapse. It's a medical emergency that requires prompt recognition.
            </p>
          </section>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
            <Card className="border-2 border-pink-200 bg-pink-50">
              <CardHeader>
                <CardTitle className="text-pink-700">Types</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Spontaneous Primary</h4>
                  <p className="text-gray-600 text-sm">No underlying lung disease, rupture of subpleural blebs</p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Spontaneous Secondary</h4>
                  <p className="text-gray-600 text-sm">Associated with underlying lung disease (COPD, cystic fibrosis)</p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Traumatic</h4>
                  <p className="text-gray-600 text-sm">Result of chest trauma or iatrogenic injury</p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Tension</h4>
                  <p className="text-gray-600 text-sm">Air cannot escape, causing hemodynamic compromise</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 border-pink-200">
              <CardHeader>
                <CardTitle className="text-pink-700">Key CXR Signs</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex gap-3">
                  <Wind className="w-5 h-5 text-pink-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">Visceral Pleural Line</p>
                    <p className="text-gray-600 text-xs">Thin white line separating collapsed lung from air</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <Wind className="w-5 h-5 text-pink-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">Absent Lung Markings</p>
                    <p className="text-gray-600 text-xs">No vessels visible in pneumothorax area</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <Wind className="w-5 h-5 text-pink-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">Mediastinal Shift</p>
                    <p className="text-gray-600 text-xs">In tension pneumothorax, heart shifts away</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex gap-4 justify-between">
            <Button variant="outline" onClick={() => navigate("/pleural-effusion")}>
              Previous: Pleural Effusion
            </Button>
            <Button onClick={() => navigate("/quick-reference")} className="bg-blue-600 hover:bg-blue-700">
              Next: Quick Reference
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
