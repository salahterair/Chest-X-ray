import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { ArrowLeft, CheckCircle2, AlertCircle } from "lucide-react";

export default function RequestingCXR() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <header className="border-b border-blue-100 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Requesting a Chest X-ray</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <section className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Clinical Indications & Best Practices</h2>
            <p className="text-lg text-gray-600 mb-6">
              A well-justified CXR request with complete clinical information helps radiologists provide accurate interpretations.
            </p>
          </section>

          <div className="flex gap-4 justify-between mt-12">
            <Button variant="outline" onClick={() => navigate("/")}>Back to Home</Button>
            <Button onClick={() => navigate("/abcde-approach")} className="bg-blue-600 hover:bg-blue-700">
              Next: ABCDE Approach
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
