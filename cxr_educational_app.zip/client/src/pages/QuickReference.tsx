import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { ArrowLeft, CheckCircle2, Printer } from "lucide-react";

export default function QuickReference() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <header className="border-b border-blue-100 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <h1 className="text-2xl font-bold text-gray-900">Quick Reference</h1>
            </div>
            <Button variant="outline" size="sm" onClick={() => window.print()}>
              <Printer className="w-4 h-4 mr-2" />
              Print
            </Button>
          </div>
        </div>
      </header>
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <section className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">CXR Interpretation Checklist</h2>
            
            <div className="space-y-6">
              {[
                {
                  letter: "A",
                  title: "Airway",
                  items: ["Trachea central?", "Carina visible?", "Main bronchi patent?", "Hila well-defined?"]
                },
                {
                  letter: "B",
                  title: "Breathing",
                  items: ["Lung fields symmetrical?", "Normal lucency?", "Vascular markings normal?", "Pleural margins sharp?"]
                },
                {
                  letter: "C",
                  title: "Circulation",
                  items: ["Heart size normal (CTR < 0.5)?", "Heart shape normal?", "Mediastinal width normal?", "Great vessels normal?"]
                },
                {
                  letter: "D",
                  title: "Diaphragm",
                  items: ["Hemidiaphragms smooth?", "Costophrenic angles sharp?", "No subdiaphragmatic air?", "Symmetric elevation?"]
                },
                {
                  letter: "E",
                  title: "Everything Else",
                  items: ["Bones intact?", "Soft tissues normal?", "Tubes/lines in place?", "Foreign bodies?"]
                }
              ].map((section) => (
                <Card key={section.letter} className="border-2 border-blue-100">
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-blue-100 text-blue-700 rounded-lg flex items-center justify-center font-bold text-xl">
                        {section.letter}
                      </div>
                      <CardTitle>{section.title}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {section.items.map((item, idx) => (
                        <div key={idx} className="flex gap-2">
                          <CheckCircle2 className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                          <span className="text-gray-700">{item}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          <section className="mb-12">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Pathology Quick Reference</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { name: "Consolidation", sign: "Air bronchograms, homogeneous opacity" },
                { name: "Atelectasis", sign: "Volume loss, mediastinal shift, silhouette sign" },
                { name: "Pleural Effusion", sign: "Meniscus sign, blunted costophrenic angle" },
                { name: "Pneumothorax", sign: "Visceral pleural line, absent lung markings" }
              ].map((item) => (
                <Card key={item.name} className="border-blue-100">
                  <CardHeader>
                    <CardTitle className="text-lg">{item.name}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 text-sm">{item.sign}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          <div className="flex gap-4 justify-between">
            <Button variant="outline" onClick={() => navigate("/pneumothorax")}>
              Previous: Pneumothorax
            </Button>
            <Button onClick={() => navigate("/clinical-cases")} className="bg-blue-600 hover:bg-blue-700">
              Next: Clinical Cases
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
