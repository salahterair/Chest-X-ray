import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { ArrowLeft, CheckCircle2 } from "lucide-react";

export default function NormalCXR() {
  const [, navigate] = useLocation();

  const features = [
    { title: "Airway", description: "Trachea is central and the carina is clearly visible" },
    { title: "Breathing", description: "Lung fields are symmetrical with normal vascular markings" },
    { title: "Circulation", description: "Heart size is normal (CTR < 0.5); hila are well-defined" },
    { title: "Diaphragm", description: "Hemidiaphragms are smooth with sharp costophrenic angles" },
    { title: "Everything Else", description: "Bones and soft tissues appear normal" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <header className="border-b border-blue-100 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Normal Chest X-ray</h1>
          </div>
        </div>
      </header>
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-5xl mx-auto">
          <section className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Establishing Your Baseline</h2>
            <p className="text-lg text-gray-600 mb-6">
              Understanding normal anatomy is essential before recognizing pathology. This page shows you what a normal CXR looks like and the key features to observe.
            </p>
          </section>

          <section className="mb-12">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">What to Look For in a Normal CXR</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { title: "Symmetry", desc: "Left and right lungs should be similar in size and appearance" },
                { title: "Clarity", desc: "Lung fields should be clear without opacities or infiltrates" },
                { title: "Borders", desc: "Heart borders and diaphragm should be clearly visible" },
                { title: "Angles", desc: "Costophrenic angles should be sharp and well-defined" },
                { title: "Vessels", desc: "Pulmonary vessels should taper gradually from hilum to periphery" },
                { title: "Trachea", desc: "Trachea should be midline and patent throughout" }
              ].map((item, idx) => (
                <Card key={idx} className="border-blue-100">
                  <CardHeader>
                    <CardTitle className="text-lg text-blue-700">{item.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 text-sm">{item.desc}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          <div className="flex gap-4 justify-between">
            <Button variant="outline" onClick={() => navigate("/abcde-approach")}>
              Previous: ABCDE Approach
            </Button>
            <Button onClick={() => navigate("/consolidation")} className="bg-blue-600 hover:bg-blue-700">
              Next: Consolidation
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
