import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { ArrowLeft, Droplet } from "lucide-react";

export default function PleauralEffusion() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <header className="border-b border-blue-100 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Pleural Effusion</h1>
          </div>
        </div>
      </header>
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-5xl mx-auto">
          <section className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Identifying Pleural Effusion</h2>
            <p className="text-lg text-gray-600 mb-6">
              Pleural effusion is fluid accumulation in the pleural space. It's one of the most common findings on CXR and can indicate various underlying conditions.
            </p>
          </section>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
            <Card className="border-2 border-purple-200 bg-purple-50">
              <CardHeader>
                <CardTitle className="text-purple-700">Common Causes</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">Transudative</h4>
                  <ul className="text-gray-600 text-sm space-y-1">
                    <li>• Heart failure (most common)</li>
                    <li>• Cirrhosis</li>
                    <li>• Nephrotic syndrome</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-1">Exudative</h4>
                  <ul className="text-gray-600 text-sm space-y-1">
                    <li>• Pneumonia (parapneumonic)</li>
                    <li>• Malignancy</li>
                    <li>• Pulmonary embolism</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 border-purple-200">
              <CardHeader>
                <CardTitle className="text-purple-700">Key CXR Features</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex gap-3">
                  <Droplet className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">Meniscus Sign</p>
                    <p className="text-gray-600 text-xs">Curved upper border of fluid against chest wall</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <Droplet className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">Blunted Costophrenic Angle</p>
                    <p className="text-gray-600 text-xs">Normally sharp angle becomes rounded</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <Droplet className="w-5 h-5 text-purple-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">Opacification</p>
                    <p className="text-gray-600 text-xs">Homogeneous opacity in dependent areas</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex gap-4 justify-between">
            <Button variant="outline" onClick={() => navigate("/collapse")}>
              Previous: Collapse
            </Button>
            <Button onClick={() => navigate("/pneumothorax")} className="bg-blue-600 hover:bg-blue-700">
              Next: Pneumothorax
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
