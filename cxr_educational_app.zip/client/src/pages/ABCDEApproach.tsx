import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function ABCDEApproach() {
  const [, navigate] = useLocation();

  const abcdeItems = [
    {
      letter: "A",
      title: "Airway",
      color: "bg-blue-100 text-blue-700",
      items: [
        "Trachea - Is it central or deviated?",
        "Carina - Is it visible and normal?",
        "Main bronchi - Are they patent and symmetrical?",
        "Hilar structures - Are they well-defined?"
      ]
    },
    {
      letter: "B",
      title: "Breathing",
      color: "bg-green-100 text-green-700",
      items: [
        "Lung fields - Are they symmetrical?",
        "Lung lucency - Is it normal or abnormal?",
        "Vascular markings - Are they visible and normal?",
        "Pleural margins - Are they sharp and clear?"
      ]
    },
    {
      letter: "C",
      title: "Circulation",
      color: "bg-red-100 text-red-700",
      items: [
        "Heart size - Is the cardiothoracic ratio < 0.5?",
        "Heart shape - Is it normal or abnormal?",
        "Mediastinal width - Is it normal?",
        "Great vessels - Are they visible and normal?"
      ]
    },
    {
      letter: "D",
      title: "Diaphragm",
      color: "bg-purple-100 text-purple-700",
      items: [
        "Hemidiaphragm contour - Are they smooth and dome-shaped?",
        "Costophrenic angles - Are they sharp and acute?",
        "Subdiaphragmatic air - Is there any free air?",
        "Diaphragm elevation - Is there asymmetry?"
      ]
    },
    {
      letter: "E",
      title: "Everything Else",
      color: "bg-indigo-100 text-indigo-700",
      items: [
        "Bones - Ribs, clavicles, vertebrae for fractures or abnormalities",
        "Soft tissues - Subcutaneous emphysema, masses",
        "Tubes and lines - ET tubes, central lines, chest tubes",
        "Foreign bodies - Metalwork, pacemakers, other devices"
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <header className="border-b border-blue-100 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">The ABCDE Approach</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-5xl mx-auto">
          <section className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Systematic CXR Interpretation</h2>
            <p className="text-lg text-gray-600 mb-6">
              The ABCDE method is a structured approach to ensure no findings are missed. Follow this systematic method every time you interpret a CXR.
            </p>
          </section>

          <Tabs defaultValue="A" className="mb-12">
            <TabsList className="grid w-full grid-cols-5 mb-8">
              {abcdeItems.map((item) => (
                <TabsTrigger key={item.letter} value={item.letter} className="text-lg font-bold">
                  {item.letter}
                </TabsTrigger>
              ))}
            </TabsList>

            {abcdeItems.map((item) => (
              <TabsContent key={item.letter} value={item.letter}>
                <Card className="border-2 border-blue-100">
                  <CardHeader>
                    <div className="flex items-center gap-4">
                      <div className={`w-16 h-16 rounded-lg ${item.color} flex items-center justify-center`}>
                        <span className="text-4xl font-bold">{item.letter}</span>
                      </div>
                      <div>
                        <CardTitle className="text-3xl">{item.title}</CardTitle>
                        <p className="text-gray-600 mt-2">Key structures and findings to assess</p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {item.items.map((itemText, idx) => (
                        <div key={idx} className="flex gap-3 p-4 bg-gray-50 rounded-lg">
                          <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center flex-shrink-0 text-sm font-bold">
                            {idx + 1}
                          </div>
                          <p className="text-gray-700">{itemText}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            ))}
          </Tabs>

          <div className="flex gap-4 justify-between">
            <Button variant="outline" onClick={() => navigate("/requesting-cxr")}>
              Previous: Requesting CXR
            </Button>
            <Button onClick={() => navigate("/normal-cxr")} className="bg-blue-600 hover:bg-blue-700">
              Next: Normal CXR
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
