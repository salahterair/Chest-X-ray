import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { ArrowLeft, AlertCircle } from "lucide-react";

export default function Consolidation() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <header className="border-b border-blue-100 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Consolidation</h1>
          </div>
        </div>
      </header>
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-5xl mx-auto">
          <section className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Recognizing Lung Consolidation</h2>
            <p className="text-lg text-gray-600 mb-6">
              Consolidation occurs when alveolar air is replaced by fluid, pus, blood, or cells. This is one of the most common pathological findings on CXR.
            </p>
          </section>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
            <Card className="border-2 border-orange-200 bg-orange-50">
              <CardHeader>
                <CardTitle className="text-orange-700">Definition & Causes</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">What is Consolidation?</h4>
                  <p className="text-gray-600 text-sm">Filling of alveolar spaces with fluid, pus, blood, or cells, making the lung tissue appear dense and white on CXR.</p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Common Causes</h4>
                  <ul className="text-gray-600 text-sm space-y-1">
                    <li>• Pneumonia (most common)</li>
                    <li>• Pulmonary edema</li>
                    <li>• Hemorrhage</li>
                    <li>• Malignancy</li>
                    <li>• Aspiration</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 border-orange-200">
              <CardHeader>
                <CardTitle className="text-orange-700">Key CXR Features</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex gap-3">
                  <AlertCircle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">Homogeneous Opacity</p>
                    <p className="text-gray-600 text-xs">White/opaque area in lobar or segmental distribution</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <AlertCircle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">Air Bronchograms</p>
                    <p className="text-gray-600 text-xs">Dark branching airways visible within white lung (hallmark sign)</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <AlertCircle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">Loss of Vascular Markings</p>
                    <p className="text-gray-600 text-xs">Normal lung vessels obscured by consolidation</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex gap-4 justify-between">
            <Button variant="outline" onClick={() => navigate("/normal-cxr")}>
              Previous: Normal CXR
            </Button>
            <Button onClick={() => navigate("/collapse")} className="bg-blue-600 hover:bg-blue-700">
              Next: Collapse (Atelectasis)
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
