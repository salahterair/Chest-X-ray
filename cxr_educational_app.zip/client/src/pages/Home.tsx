import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { BookOpen, Stethoscope, Brain, Zap, CheckCircle2, Microscope } from "lucide-react";

export default function Home() {
  const [, navigate] = useLocation();

  const modules = [
    {
      title: "Requesting a CXR",
      description: "Learn how to properly request a chest X-ray with essential clinical information",
      icon: Stethoscope,
      path: "/requesting-cxr",
      color: "bg-blue-50 text-blue-700",
      borderColor: "border-blue-200"
    },
    {
      title: "ABCDE Approach",
      description: "Master the systematic interpretation method used by radiologists",
      icon: Brain,
      path: "/abcde-approach",
      color: "bg-indigo-50 text-indigo-700",
      borderColor: "border-indigo-200"
    },
    {
      title: "Normal CXR",
      description: "Understand normal anatomy and establish your baseline for comparison",
      icon: CheckCircle2,
      path: "/normal-cxr",
      color: "bg-green-50 text-green-700",
      borderColor: "border-green-200"
    },
    {
      title: "Consolidation",
      description: "Recognize alveolar filling patterns and air bronchograms",
      icon: Microscope,
      path: "/consolidation",
      color: "bg-orange-50 text-orange-700",
      borderColor: "border-orange-200"
    },
    {
      title: "Collapse (Atelectasis)",
      description: "Identify volume loss signs and mediastinal shift patterns",
      icon: Zap,
      path: "/collapse",
      color: "bg-red-50 text-red-700",
      borderColor: "border-red-200"
    },
    {
      title: "Pleural Effusion",
      description: "Learn to spot the meniscus sign and blunted costophrenic angles",
      icon: BookOpen,
      path: "/pleural-effusion",
      color: "bg-purple-50 text-purple-700",
      borderColor: "border-purple-200"
    },
    {
      title: "Pneumothorax",
      description: "Detect visceral pleural lines and absent lung markings",
      icon: Zap,
      path: "/pneumothorax",
      color: "bg-pink-50 text-pink-700",
      borderColor: "border-pink-200"
    },
    {
      title: "Quick Reference",
      description: "ABCDE checklist, key findings, and differential diagnosis guide",
      icon: CheckCircle2,
      path: "/quick-reference",
      color: "bg-teal-50 text-teal-700",
      borderColor: "border-teal-200"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <header className="border-b border-blue-100 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                <Microscope className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900">CXR Learning Hub</h1>
            </div>
            <p className="text-sm text-gray-600">Chest X-ray Interpretation for Medical Students</p>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Master Chest X-ray Interpretation</h2>
          <p className="text-xl text-gray-600 mb-8">
            A comprehensive, interactive learning platform designed for medical students to understand CXR requesting, systematic interpretation, and recognition of common lung pathological patterns.
          </p>
          <div className="flex gap-4 justify-center">
            <Button 
              size="lg" 
              onClick={() => navigate("/requesting-cxr")}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Start Learning
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              onClick={() => navigate("/quick-reference")}
            >
              Quick Reference
            </Button>
          </div>
        </div>
      </section>

      {/* Learning Modules Grid */}
      <section className="container mx-auto px-4 py-12">
        <h3 className="text-2xl font-bold text-gray-900 mb-8">Learning Modules</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {modules.map((module) => {
            const Icon = module.icon;
            return (
              <Card 
                key={module.path}
                className={`cursor-pointer hover:shadow-lg transition-all duration-300 border-2 ${module.borderColor}`}
                onClick={() => navigate(module.path)}
              >
                <CardHeader>
                  <div className={`w-12 h-12 rounded-lg ${module.color} flex items-center justify-center mb-4`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <CardTitle className="text-lg">{module.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-sm">{module.description}</CardDescription>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-16">
        <div className="bg-white rounded-xl border border-blue-100 p-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-8">Why This Learning Platform?</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <BookOpen className="w-6 h-6 text-blue-600" />
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Structured Learning</h4>
                <p className="text-gray-600 text-sm">Follow a logical progression from requesting to interpretation to pathology recognition.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                  <Brain className="w-6 h-6 text-indigo-600" />
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Interactive Content</h4>
                <p className="text-gray-600 text-sm">Engage with high-quality medical images and guided interpretation modules.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <CheckCircle2 className="w-6 h-6 text-green-600" />
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Clinical Accuracy</h4>
                <p className="text-gray-600 text-sm">Learn from real clinical cases and evidence-based diagnostic criteria.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-blue-100 bg-white mt-16">
        <div className="container mx-auto px-4 py-8 text-center text-gray-600 text-sm">
          <p>CXR Learning Hub • Medical Education Platform • For Educational Purposes</p>
        </div>
      </footer>
    </div>
  );
}
