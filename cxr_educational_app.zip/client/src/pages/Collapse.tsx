import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { ArrowLeft, AlertTriangle } from "lucide-react";

export default function Collapse() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <header className="border-b border-blue-100 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Collapse (Atelectasis)</h1>
          </div>
        </div>
      </header>
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-5xl mx-auto">
          <section className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Understanding Atelectasis</h2>
            <p className="text-lg text-gray-600 mb-6">
              Atelectasis (collapse) occurs when lung tissue loses air content, resulting in volume loss. This is a common finding in hospitalized patients.
            </p>
          </section>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
            <Card className="border-2 border-red-200 bg-red-50">
              <CardHeader>
                <CardTitle className="text-red-700">Types of Atelectasis</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Obstructive</h4>
                  <p className="text-gray-600 text-sm">Caused by airway obstruction (mucus plug, tumor, foreign body)</p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Compressive</h4>
                  <p className="text-gray-600 text-sm">Caused by external compression (pleural effusion, pneumothorax, mass)</p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Adhesive</h4>
                  <p className="text-gray-600 text-sm">Caused by loss of surfactant (ARDS, post-operative)</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 border-red-200">
              <CardHeader>
                <CardTitle className="text-red-700">Key CXR Signs</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex gap-3">
                  <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">Volume Loss</p>
                    <p className="text-gray-600 text-xs">Affected lobe appears smaller and denser</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">Mediastinal Shift</p>
                    <p className="text-gray-600 text-xs">Trachea and heart shift toward collapsed lobe</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">Elevated Hemidiaphragm</p>
                    <p className="text-gray-600 text-xs">Diaphragm rises on affected side</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-gray-900 text-sm">Silhouette Sign</p>
                    <p className="text-gray-600 text-xs">Loss of normal heart/mediastinal borders</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex gap-4 justify-between">
            <Button variant="outline" onClick={() => navigate("/consolidation")}>
              Previous: Consolidation
            </Button>
            <Button onClick={() => navigate("/pleural-effusion")} className="bg-blue-600 hover:bg-blue-700">
              Next: Pleural Effusion
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
