import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { ArrowLeft, Stethoscope } from "lucide-react";
import { useState } from "react";

export default function ClinicalCases() {
  const [, navigate] = useLocation();
  const [expandedCase, setExpandedCase] = useState<number | null>(null);

  const cases = [
    {
      id: 1,
      title: "Case 1: Community-Acquired Pneumonia",
      presentation: "45-year-old male with 3-day history of fever, cough, and dyspnea. Vital signs: Temp 38.5°C, RR 24, O2 sat 92%.",
      findings: "Right lower lobe consolidation with air bronchograms. No pleural effusion.",
      diagnosis: "Community-acquired pneumonia (CAP)",
      management: "Antibiotic therapy, supportive care, follow-up CXR in 4-6 weeks"
    },
    {
      id: 2,
      title: "Case 2: Acute Decompensated Heart Failure",
      presentation: "68-year-old female with acute dyspnea, orthopnea, and lower extremity edema. History of hypertension and diabetes.",
      findings: "Bilateral perihilar consolidation, cardiomegaly (CTR > 0.5), bilateral pleural effusions",
      diagnosis: "Acute decompensated heart failure with pulmonary edema",
      management: "Diuretics, ACE inhibitors, echocardiography, ICU monitoring"
    },
    {
      id: 3,
      title: "Case 3: Spontaneous Pneumothorax",
      presentation: "22-year-old tall male with acute left-sided chest pain and dyspnea. No trauma history.",
      findings: "Left pneumothorax with visceral pleural line, absent lung markings on left, normal mediastinal position",
      diagnosis: "Spontaneous primary pneumothorax",
      management: "Observation if small (<2cm), chest tube if large or symptomatic"
    },
    {
      id: 4,
      title: "Case 4: Pleural Effusion",
      presentation: "55-year-old male with progressive dyspnea and chest discomfort. Known history of cirrhosis.",
      findings: "Right-sided pleural effusion with meniscus sign, blunted right costophrenic angle",
      diagnosis: "Pleural effusion secondary to cirrhosis (transudative)",
      management: "Diuretics, sodium restriction, thoracentesis if symptomatic"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <header className="border-b border-blue-100 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Clinical Cases</h1>
          </div>
        </div>
      </header>
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <section className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Real-World Clinical Scenarios</h2>
            <p className="text-lg text-gray-600 mb-6">
              Apply your CXR interpretation skills to these clinical cases. Review the presentation, identify findings, and consider the diagnosis and management.
            </p>
          </section>

          <div className="space-y-4 mb-12">
            {cases.map((caseItem) => (
              <Card 
                key={caseItem.id}
                className="border-2 border-blue-100 cursor-pointer hover:shadow-lg transition-all"
                onClick={() => setExpandedCase(expandedCase === caseItem.id ? null : caseItem.id)}
              >
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Stethoscope className="w-6 h-6 text-blue-600" />
                      <CardTitle>{caseItem.title}</CardTitle>
                    </div>
                    <span className="text-2xl">{expandedCase === caseItem.id ? "−" : "+"}</span>
                  </div>
                </CardHeader>
                {expandedCase === caseItem.id && (
                  <CardContent className="space-y-4 border-t border-blue-100 pt-4">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Clinical Presentation</h4>
                      <p className="text-gray-600">{caseItem.presentation}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">CXR Findings</h4>
                      <p className="text-gray-600">{caseItem.findings}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Diagnosis</h4>
                      <p className="text-gray-600">{caseItem.diagnosis}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Management</h4>
                      <p className="text-gray-600">{caseItem.management}</p>
                    </div>
                  </CardContent>
                )}
              </Card>
            ))}
          </div>

          <div className="flex gap-4 justify-between">
            <Button variant="outline" onClick={() => navigate("/quick-reference")}>
              Previous: Quick Reference
            </Button>
            <Button onClick={() => navigate("/")} className="bg-blue-600 hover:bg-blue-700">
              Back to Home
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
