import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import RequestingCXR from "./pages/RequestingCXR";
import ABCDEApproach from "./pages/ABCDEApproach";
import NormalCXR from "./pages/NormalCXR";
import Consolidation from "./pages/Consolidation";
import Collapse from "./pages/Collapse";
import PleauralEffusion from "./pages/PleauralEffusion";
import Pneumothorax from "./pages/Pneumothorax";
import QuickReference from "./pages/QuickReference";
import ClinicalCases from "./pages/ClinicalCases";


function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/requesting-cxr"} component={RequestingCXR} />
      <Route path={"/abcde-approach"} component={ABCDEApproach} />
      <Route path={"/normal-cxr"} component={NormalCXR} />
      <Route path={"/consolidation"} component={Consolidation} />
      <Route path={"/collapse"} component={Collapse} />
      <Route path={"/pleural-effusion"} component={PleauralEffusion} />
      <Route path={"/pneumothorax"} component={Pneumothorax} />
      <Route path={"/quick-reference"} component={QuickReference} />
      <Route path={"/clinical-cases"} component={ClinicalCases} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
